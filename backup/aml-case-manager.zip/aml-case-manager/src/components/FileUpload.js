import React, { useRef, useState } from 'react';
import { Upload, FileSpreadsheet, CheckCircle, AlertCircle } from 'lucide-react';

export default function FileUpload({ label, onFile, accepted, status, hint }) {
  const ref = useRef();
  const [dragging, setDragging] = useState(false);

  const handle = (file) => {
    if (!file) return;
    if (!file.name.match(/\.(xlsx|xls)$/i)) {
      alert('Please upload an Excel file (.xlsx or .xls)');
      return;
    }
    onFile(file);
  };

  return (
    <div style={{ fontFamily:"'IBM Plex Sans', sans-serif" }}>
      <label style={{ display:'block', color:'#94a3b8', fontSize:11, fontWeight:600, letterSpacing:'.5px', marginBottom:8, textTransform:'uppercase' }}>{label}</label>
      <div
        onClick={() => ref.current.click()}
        onDragOver={e => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={e => { e.preventDefault(); setDragging(false); handle(e.dataTransfer.files[0]); }}
        style={{
          border: `2px dashed ${dragging ? '#3b82f6' : status === 'ok' ? '#22c55e' : status === 'error' ? '#ef4444' : 'rgba(71,85,105,0.5)'}`,
          borderRadius: 10, padding:'16px 20px', cursor:'pointer', transition:'all .15s',
          background: dragging ? 'rgba(59,130,246,0.05)' : 'rgba(15,23,42,0.5)',
          display:'flex', alignItems:'center', gap:12
        }}>
        <input ref={ref} type="file" accept=".xlsx,.xls" style={{ display:'none' }} onChange={e => handle(e.target.files[0])} />
        
        <div style={{ flexShrink:0 }}>
          {status === 'ok'    ? <CheckCircle  size={22} color="#22c55e" /> :
           status === 'error' ? <AlertCircle  size={22} color="#ef4444" /> :
                                <FileSpreadsheet size={22} color="#475569" />}
        </div>
        
        <div>
          <div style={{ color: status === 'ok' ? '#4ade80' : status === 'error' ? '#fca5a5' : '#94a3b8', fontSize:13, fontWeight:500 }}>
            {hint || 'Click or drag to upload'}
          </div>
          <div style={{ color:'#475569', fontSize:11, marginTop:2 }}>Supports .xlsx and .xls</div>
        </div>

        <Upload size={14} color="#334155" style={{ marginLeft:'auto' }} />
      </div>
    </div>
  );
}

import React, { useState } from 'react';
import { useAuth, USERS, ROLE_PERMISSIONS } from '../context/AuthContext';
import { Shield, Eye, EyeOff, Lock, User } from 'lucide-react';

export default function Login() {
  const { login, error, setError } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);

  const handle = async (e) => {
    e.preventDefault();
    setLoading(true);
    await new Promise(r => setTimeout(r, 400));
    login(username, password);
    setLoading(false);
  };

  const quickLogin = (u) => { setUsername(u.username); setPassword(u.password); setError(''); };

  const roleColors = { admin: '#f59e0b', supervisor: '#8b5cf6', analyst: '#3b82f6', readonly: '#6b7280' };

  return (
    <div style={{ minHeight:'100vh', background:'#0a0f1a', display:'flex', alignItems:'center', justifyContent:'center', fontFamily:"'IBM Plex Sans', sans-serif", padding:'1rem' }}>
      {/* BG grid */}
      <div style={{ position:'fixed', inset:0, backgroundImage:'linear-gradient(rgba(59,130,246,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(59,130,246,0.04) 1px, transparent 1px)', backgroundSize:'48px 48px', pointerEvents:'none' }} />

      <div style={{ position:'relative', display:'flex', flexDirection:'column', alignItems:'center', width:'100%', maxWidth:440 }}>

        {/* Logo */}
        <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:32 }}>
          <div style={{ width:48, height:48, borderRadius:12, background:'linear-gradient(135deg,#1d4ed8,#3b82f6)', display:'flex', alignItems:'center', justifyContent:'center', boxShadow:'0 0 32px rgba(59,130,246,0.4)' }}>
            <Shield size={26} color="#fff" />
          </div>
          <div>
            <div style={{ color:'#f1f5f9', fontSize:18, fontWeight:700, letterSpacing:'-0.5px' }}>AML Case Manager</div>
            <div style={{ color:'#475569', fontSize:11, fontFamily:"'IBM Plex Mono', monospace", letterSpacing:1 }}>FINANCIAL CRIME SURVEILLANCE</div>
          </div>
        </div>

        {/* Card */}
        <div style={{ width:'100%', background:'rgba(15,23,42,0.9)', border:'1px solid rgba(59,130,246,0.2)', borderRadius:16, padding:32, backdropFilter:'blur(12px)', boxShadow:'0 24px 64px rgba(0,0,0,0.5)' }}>
          <h2 style={{ color:'#f1f5f9', fontSize:20, fontWeight:600, marginBottom:4 }}>Sign in to your account</h2>
          <p style={{ color:'#64748b', fontSize:13, marginBottom:28 }}>Authorized personnel only · All activity is monitored</p>

          <form onSubmit={handle}>
            {/* Username */}
            <label style={{ display:'block', color:'#94a3b8', fontSize:12, fontWeight:600, letterSpacing:'.5px', marginBottom:6 }}>USERNAME</label>
            <div style={{ position:'relative', marginBottom:16 }}>
              <User size={15} color="#475569" style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)' }} />
              <input value={username} onChange={e => { setUsername(e.target.value); setError(''); }}
                placeholder="Enter username" required
                style={{ width:'100%', background:'rgba(30,41,59,0.8)', border:'1px solid rgba(71,85,105,0.5)', borderRadius:8, padding:'10px 12px 10px 36px', color:'#e2e8f0', fontSize:14, outline:'none', boxSizing:'border-box', transition:'border-color .15s' }}
                onFocus={e=>e.target.style.borderColor='rgba(59,130,246,0.6)'}
                onBlur={e=>e.target.style.borderColor='rgba(71,85,105,0.5)'} />
            </div>

            {/* Password */}
            <label style={{ display:'block', color:'#94a3b8', fontSize:12, fontWeight:600, letterSpacing:'.5px', marginBottom:6 }}>PASSWORD</label>
            <div style={{ position:'relative', marginBottom:24 }}>
              <Lock size={15} color="#475569" style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)' }} />
              <input value={password} onChange={e => { setPassword(e.target.value); setError(''); }}
                type={showPw ? 'text' : 'password'} placeholder="Enter password" required
                style={{ width:'100%', background:'rgba(30,41,59,0.8)', border:'1px solid rgba(71,85,105,0.5)', borderRadius:8, padding:'10px 36px 10px 36px', color:'#e2e8f0', fontSize:14, outline:'none', boxSizing:'border-box', transition:'border-color .15s' }}
                onFocus={e=>e.target.style.borderColor='rgba(59,130,246,0.6)'}
                onBlur={e=>e.target.style.borderColor='rgba(71,85,105,0.5)'} />
              <button type="button" onClick={() => setShowPw(!showPw)} style={{ position:'absolute', right:10, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'#475569', padding:2 }}>
                {showPw ? <EyeOff size={15}/> : <Eye size={15}/>}
              </button>
            </div>

            {error && <div style={{ background:'rgba(239,68,68,0.1)', border:'1px solid rgba(239,68,68,0.3)', borderRadius:8, padding:'10px 14px', color:'#fca5a5', fontSize:13, marginBottom:16 }}>{error}</div>}

            <button type="submit" disabled={loading}
              style={{ width:'100%', background:'linear-gradient(135deg,#1d4ed8,#3b82f6)', border:'none', borderRadius:8, padding:'12px', color:'#fff', fontSize:14, fontWeight:600, cursor: loading ? 'wait' : 'pointer', letterSpacing:'.3px', transition:'opacity .15s', opacity: loading ? 0.7 : 1 }}>
              {loading ? 'Authenticating…' : 'Sign In'}
            </button>
          </form>
        </div>

        {/* Quick login hints */}
        <div style={{ marginTop:24, width:'100%', background:'rgba(15,23,42,0.7)', border:'1px solid rgba(59,130,246,0.1)', borderRadius:12, padding:20 }}>
          <p style={{ color:'#475569', fontSize:11, fontWeight:600, letterSpacing:1, marginBottom:12, textTransform:'uppercase' }}>Demo Credentials</p>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 }}>
            {USERS.map(u => (
              <button key={u.id} onClick={() => quickLogin(u)}
                style={{ background:'rgba(30,41,59,0.6)', border:'1px solid rgba(71,85,105,0.3)', borderRadius:8, padding:'8px 12px', cursor:'pointer', textAlign:'left', transition:'border-color .15s' }}
                onMouseEnter={e=>e.currentTarget.style.borderColor='rgba(59,130,246,0.4)'}
                onMouseLeave={e=>e.currentTarget.style.borderColor='rgba(71,85,105,0.3)'}>
                <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                  <span style={{ width:8, height:8, borderRadius:'50%', background: roleColors[u.role], display:'inline-block', flexShrink:0 }} />
                  <div>
                    <div style={{ color:'#cbd5e1', fontSize:12, fontWeight:500 }}>{u.username}</div>
                    <div style={{ color:'#475569', fontSize:10, fontFamily:"'IBM Plex Mono', monospace" }}>{u.role} · {u.password}</div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

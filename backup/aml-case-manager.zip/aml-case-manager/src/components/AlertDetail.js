import React, { useState } from 'react';
import { X, ArrowRight, User, Calendar, DollarSign, MapPin, AlertTriangle, CheckCircle, Clock, ChevronRight } from 'lucide-react';
import { getAllowedTransitions } from '../utils/excelParser';
import { useAuth } from '../context/AuthContext';

const STATUS_STYLE = {
  'Open':      { bg:'rgba(59,130,246,0.15)', color:'#93c5fd', border:'rgba(59,130,246,0.3)' },
  'In Review': { bg:'rgba(251,191,36,0.15)', color:'#fde68a', border:'rgba(251,191,36,0.3)' },
  'Escalated': { bg:'rgba(239,68,68,0.15)',  color:'#fca5a5', border:'rgba(239,68,68,0.3)' },
  'Closed':    { bg:'rgba(34,197,94,0.15)',  color:'#86efac', border:'rgba(34,197,94,0.3)' },
  'Rejected':  { bg:'rgba(107,114,128,0.15)',color:'#9ca3af', border:'rgba(107,114,128,0.3)'},
};

const PRIORITY_STYLE = {
  'Critical': { color:'#ef4444' },
  'High':     { color:'#f97316' },
  'Medium':   { color:'#eab308' },
  'Low':      { color:'#22c55e' },
};

function StatusBadge({ status }) {
  const s = STATUS_STYLE[status] || STATUS_STYLE['Open'];
  return <span style={{ background:s.bg, color:s.color, border:`1px solid ${s.border}`, borderRadius:20, padding:'3px 10px', fontSize:11, fontWeight:600 }}>{status}</span>;
}

export default function AlertDetail({ alert, workflowMap, onClose, onStatusChange }) {
  const { permissions, user } = useAuth();
  const [comment, setComment] = useState('');
  const [transitioning, setTransitioning] = useState(false);
  const [auditLog, setAuditLog] = useState([]);
  const [activeTab, setActiveTab] = useState('details');

  const typeId = String(alert['Alert Type ID'] || '');
  const currentStatus = alert['Status'] || 'Open';
  const allowed = getAllowedTransitions(workflowMap, typeId, currentStatus);

  const doTransition = (targetStatus) => {
    if (!comment.trim()) { alert('Please add a comment before transitioning.'); return; }
    setTransitioning(true);
    setTimeout(() => {
      const entry = { from: currentStatus, to: targetStatus, by: user.name, at: new Date().toLocaleString(), comment };
      setAuditLog(prev => [entry, ...prev]);
      onStatusChange(alert['Alert ID'], targetStatus);
      setComment('');
      setTransitioning(false);
    }, 400);
  };

  const Field = ({ icon: Icon, label, value, mono }) => (
    <div style={{ display:'flex', flexDirection:'column', gap:3 }}>
      <div style={{ display:'flex', alignItems:'center', gap:5, color:'#475569', fontSize:10, fontWeight:600, letterSpacing:.5, textTransform:'uppercase' }}>
        {Icon && <Icon size={11} />}{label}
      </div>
      <div style={{ color:'#e2e8f0', fontSize:13, fontFamily: mono ? "'IBM Plex Mono',monospace" : undefined }}>{value || '—'}</div>
    </div>
  );

  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.75)', zIndex:500, display:'flex', alignItems:'center', justifyContent:'center', padding:16, backdropFilter:'blur(4px)', fontFamily:"'IBM Plex Sans',sans-serif" }}
      onClick={e => { if(e.target === e.currentTarget) onClose(); }}>
      
      <div style={{ width:'100%', maxWidth:760, maxHeight:'90vh', background:'#0f172a', border:'1px solid rgba(59,130,246,0.2)', borderRadius:16, overflow:'hidden', display:'flex', flexDirection:'column', boxShadow:'0 32px 96px rgba(0,0,0,0.7)' }}>
        
        {/* Header */}
        <div style={{ padding:'20px 24px', borderBottom:'1px solid rgba(71,85,105,0.3)', display:'flex', alignItems:'center', justifyContent:'space-between', background:'rgba(15,23,42,0.8)' }}>
          <div style={{ display:'flex', alignItems:'center', gap:12 }}>
            <div>
              <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                <span style={{ color:'#f1f5f9', fontSize:16, fontWeight:700, fontFamily:"'IBM Plex Mono',monospace" }}>{alert['Alert ID']}</span>
                <StatusBadge status={currentStatus} />
                {alert['Priority'] && <span style={{ color: PRIORITY_STYLE[alert['Priority']]?.color || '#94a3b8', fontSize:11, fontWeight:700 }}>● {alert['Priority']}</span>}
              </div>
              <div style={{ color:'#64748b', fontSize:12, marginTop:3 }}>{alert['Alert Type']} · Score: <span style={{ color:'#fde68a', fontFamily:"'IBM Plex Mono',monospace" }}>{alert['Score']}</span></div>
            </div>
          </div>
          <button onClick={onClose} style={{ background:'rgba(71,85,105,0.2)', border:'1px solid rgba(71,85,105,0.3)', borderRadius:8, padding:6, cursor:'pointer', color:'#94a3b8' }}><X size={16}/></button>
        </div>

        {/* Tabs */}
        <div style={{ display:'flex', borderBottom:'1px solid rgba(71,85,105,0.3)', background:'rgba(10,15,26,0.5)' }}>
          {['details','workflow','audit'].map(tab => (
            <button key={tab} onClick={() => setActiveTab(tab)}
              style={{ padding:'12px 20px', background:'none', border:'none', borderBottom: activeTab===tab ? '2px solid #3b82f6' : '2px solid transparent', color: activeTab===tab ? '#93c5fd' : '#475569', fontSize:12, fontWeight:600, textTransform:'uppercase', letterSpacing:.5, cursor:'pointer', transition:'color .15s' }}>
              {tab}
            </button>
          ))}
        </div>

        <div style={{ flex:1, overflow:'auto', padding:24 }}>

          {/* DETAILS TAB */}
          {activeTab === 'details' && (
            <div>
              {/* Customer info */}
              <div style={{ background:'rgba(30,41,59,0.4)', border:'1px solid rgba(71,85,105,0.25)', borderRadius:12, padding:20, marginBottom:16 }}>
                <div style={{ color:'#94a3b8', fontSize:10, fontWeight:700, letterSpacing:1, textTransform:'uppercase', marginBottom:14 }}>Customer Information</div>
                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:16 }}>
                  <Field icon={User}     label="Customer Name"  value={alert['Customer Name']} />
                  <Field icon={User}     label="Customer ID"    value={alert['Customer ID']} mono />
                  <Field icon={MapPin}   label="Country"        value={alert['Country']} mono />
                </div>
              </div>

              {/* Transaction info */}
              <div style={{ background:'rgba(30,41,59,0.4)', border:'1px solid rgba(71,85,105,0.25)', borderRadius:12, padding:20, marginBottom:16 }}>
                <div style={{ color:'#94a3b8', fontSize:10, fontWeight:700, letterSpacing:1, textTransform:'uppercase', marginBottom:14 }}>Transaction Details</div>
                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:16 }}>
                  <Field icon={DollarSign} label="Amount"   value={alert['Amount'] ? `${Number(alert['Amount']).toLocaleString()} ${alert['Currency']}` : '—'} mono />
                  <Field icon={Calendar}   label="Created"  value={alert['Created Date']} mono />
                  <Field icon={User}       label="Assigned" value={alert['Assigned To']} mono />
                </div>
              </div>

              {/* Description */}
              <div style={{ background:'rgba(59,130,246,0.05)', border:'1px solid rgba(59,130,246,0.15)', borderRadius:12, padding:20 }}>
                <div style={{ color:'#94a3b8', fontSize:10, fontWeight:700, letterSpacing:1, textTransform:'uppercase', marginBottom:10 }}>Alert Description</div>
                <div style={{ color:'#cbd5e1', fontSize:13, lineHeight:1.7 }}>{alert['Description'] || 'No description provided.'}</div>
              </div>

              {/* All raw fields */}
              <div style={{ marginTop:16 }}>
                <div style={{ color:'#334155', fontSize:10, fontWeight:600, letterSpacing:1, textTransform:'uppercase', marginBottom:10 }}>All Fields</div>
                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:6 }}>
                  {Object.entries(alert).map(([k, v]) => (
                    <div key={k} style={{ display:'flex', gap:8, padding:'4px 0' }}>
                      <span style={{ color:'#334155', fontSize:11, minWidth:110, flexShrink:0 }}>{k}</span>
                      <span style={{ color:'#64748b', fontSize:11, fontFamily:"'IBM Plex Mono',monospace", wordBreak:'break-all' }}>{String(v)}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* WORKFLOW TAB */}
          {activeTab === 'workflow' && (
            <div>
              <div style={{ background:'rgba(30,41,59,0.4)', border:'1px solid rgba(71,85,105,0.25)', borderRadius:12, padding:20, marginBottom:16 }}>
                <div style={{ color:'#94a3b8', fontSize:10, fontWeight:700, letterSpacing:1, textTransform:'uppercase', marginBottom:14 }}>Current State</div>
                <div style={{ display:'flex', alignItems:'center', gap:12, flexWrap:'wrap' }}>
                  <StatusBadge status={currentStatus} />
                  {allowed.length > 0 && <ArrowRight size={16} color="#475569" />}
                  {allowed.map(s => <StatusBadge key={s} status={s} />)}
                  {allowed.length === 0 && <span style={{ color:'#475569', fontSize:12 }}>No further transitions allowed from this state.</span>}
                </div>
              </div>

              {permissions.canTransition && allowed.length > 0 && (
                <>
                  <div style={{ marginBottom:12 }}>
                    <label style={{ display:'block', color:'#94a3b8', fontSize:11, fontWeight:600, letterSpacing:.5, textTransform:'uppercase', marginBottom:8 }}>Analyst Comment *</label>
                    <textarea value={comment} onChange={e=>setComment(e.target.value)} rows={3}
                      placeholder="Add a comment explaining this transition…"
                      style={{ width:'100%', background:'rgba(15,23,42,0.8)', border:'1px solid rgba(71,85,105,0.4)', borderRadius:8, padding:'10px 12px', color:'#e2e8f0', fontSize:13, resize:'vertical', outline:'none', boxSizing:'border-box', fontFamily:"'IBM Plex Sans',sans-serif" }} />
                  </div>

                  <div style={{ color:'#94a3b8', fontSize:11, fontWeight:600, letterSpacing:.5, textTransform:'uppercase', marginBottom:10 }}>Transition To</div>
                  <div style={{ display:'flex', gap:10, flexWrap:'wrap' }}>
                    {allowed.map(target => (
                      <button key={target} onClick={() => doTransition(target)} disabled={transitioning}
                        style={{ display:'flex', alignItems:'center', gap:8, background:'rgba(59,130,246,0.1)', border:'1px solid rgba(59,130,246,0.3)', borderRadius:8, padding:'10px 18px', cursor:'pointer', color:'#93c5fd', fontSize:13, fontWeight:600, transition:'all .15s' }}
                        onMouseEnter={e=>{ e.currentTarget.style.background='rgba(59,130,246,0.2)'; e.currentTarget.style.borderColor='rgba(59,130,246,0.6)'; }}
                        onMouseLeave={e=>{ e.currentTarget.style.background='rgba(59,130,246,0.1)'; e.currentTarget.style.borderColor='rgba(59,130,246,0.3)'; }}>
                        <ChevronRight size={14} /> {target}
                      </button>
                    ))}
                  </div>
                </>
              )}

              {!permissions.canTransition && (
                <div style={{ background:'rgba(107,114,128,0.1)', border:'1px solid rgba(107,114,128,0.2)', borderRadius:10, padding:16, color:'#6b7280', fontSize:13 }}>
                  Your role does not have permission to perform workflow transitions.
                </div>
              )}
            </div>
          )}

          {/* AUDIT TAB */}
          {activeTab === 'audit' && (
            <div>
              {auditLog.length === 0 ? (
                <div style={{ color:'#334155', fontSize:13, textAlign:'center', padding:'40px 0' }}>No workflow transitions recorded in this session.</div>
              ) : auditLog.map((e, i) => (
                <div key={i} style={{ background:'rgba(30,41,59,0.4)', border:'1px solid rgba(71,85,105,0.25)', borderRadius:10, padding:16, marginBottom:10 }}>
                  <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:8 }}>
                    <StatusBadge status={e.from} />
                    <ArrowRight size={13} color="#475569" />
                    <StatusBadge status={e.to} />
                    <span style={{ color:'#475569', fontSize:11, marginLeft:'auto', fontFamily:"'IBM Plex Mono',monospace" }}>{e.at}</span>
                  </div>
                  <div style={{ color:'#64748b', fontSize:12 }}>By <span style={{ color:'#94a3b8' }}>{e.by}</span> · {e.comment}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

import React, { useState } from 'react';
import { Shield, ArrowRight, Info } from 'lucide-react';
import FileUpload from './FileUpload';
import { parseAlertsWorkbook, parseWorkflowWorkbook } from '../utils/excelParser';

export default function SetupScreen({ onReady }) {
  const [alertsFile, setAlertsFile]     = useState(null);
  const [workflowFile, setWorkflowFile] = useState(null);
  const [alertsStatus, setAlertsStatus]     = useState(null);
  const [workflowStatus, setWorkflowStatus] = useState(null);
  const [alertsHint, setAlertsHint]     = useState(null);
  const [workflowHint, setWorkflowHint] = useState(null);
  const [loading, setLoading]           = useState(false);
  const [error, setError]               = useState('');

  const handleAlerts = async (file) => {
    setAlertsFile(file); setAlertsStatus(null); setAlertsHint('Parsing…');
    try {
      const result = await parseAlertsWorkbook(file);
      const total  = Object.values(result.alertsByView).reduce((n,a) => n+a.length, 0);
      setAlertsStatus('ok');
      setAlertsHint(`✓ ${file.name} — ${result.views.length} views, ${total} alerts`);
      setAlertsFile({ file, result });
    } catch(e) {
      setAlertsStatus('error'); setAlertsHint(`Error: ${e.message}`);
    }
  };

  const handleWorkflow = async (file) => {
    setWorkflowFile(file); setWorkflowStatus(null); setWorkflowHint('Parsing…');
    try {
      const result = await parseWorkflowWorkbook(file);
      const types  = Object.keys(result).length;
      setWorkflowStatus('ok');
      setWorkflowHint(`✓ ${file.name} — ${types} alert types configured`);
      setWorkflowFile({ file, result });
    } catch(e) {
      setWorkflowStatus('error'); setWorkflowHint(`Error: ${e.message}`);
    }
  };

  const launch = () => {
    if (!alertsFile?.result) { setError('Please upload the alerts Excel file.'); return; }
    setLoading(true);
    setTimeout(() => {
      onReady({
        views: alertsFile.result.views,
        alertsByView: alertsFile.result.alertsByView,
        workflowMap: workflowFile?.result || {},
      });
    }, 300);
  };

  return (
    <div style={{ minHeight:'100vh', background:'#0a0f1a', display:'flex', alignItems:'center', justifyContent:'center', fontFamily:"'IBM Plex Sans',sans-serif", padding:'1rem' }}>
      <div style={{ position:'fixed', inset:0, backgroundImage:'linear-gradient(rgba(59,130,246,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(59,130,246,0.04) 1px, transparent 1px)', backgroundSize:'48px 48px', pointerEvents:'none' }} />

      <div style={{ position:'relative', width:'100%', maxWidth:560 }}>
        {/* Header */}
        <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:28 }}>
          <div style={{ width:44, height:44, borderRadius:10, background:'linear-gradient(135deg,#1d4ed8,#3b82f6)', display:'flex', alignItems:'center', justifyContent:'center', boxShadow:'0 0 24px rgba(59,130,246,0.4)' }}>
            <Shield size={22} color="#fff" />
          </div>
          <div>
            <div style={{ color:'#f1f5f9', fontSize:18, fontWeight:700 }}>Load Alert Data</div>
            <div style={{ color:'#475569', fontSize:12 }}>Upload your Excel files to populate the workbench</div>
          </div>
        </div>

        {/* Card */}
        <div style={{ background:'rgba(15,23,42,0.9)', border:'1px solid rgba(59,130,246,0.15)', borderRadius:16, padding:28, boxShadow:'0 24px 64px rgba(0,0,0,0.5)' }}>

          <div style={{ display:'flex', flexDirection:'column', gap:20 }}>
            <FileUpload label="Alerts Data (required)" onFile={handleAlerts} status={alertsStatus} hint={alertsHint} />
            <FileUpload label="Workflow Config (optional)" onFile={handleWorkflow} status={workflowStatus} hint={workflowHint} />
          </div>

          {/* Hint box */}
          <div style={{ background:'rgba(59,130,246,0.05)', border:'1px solid rgba(59,130,246,0.15)', borderRadius:10, padding:'12px 16px', marginTop:20, display:'flex', gap:10 }}>
            <Info size={14} color="#3b82f6" style={{ flexShrink:0, marginTop:1 }} />
            <div style={{ color:'#64748b', fontSize:12, lineHeight:1.7 }}>
              <strong style={{ color:'#94a3b8' }}>Alerts file:</strong> Each sheet name = one Alert View (e.g. "Party IB"). Columns must include: Alert ID, Customer ID, Customer Name, Alert Type, Alert Type ID, Score, Status, Assigned To, Created Date, Amount, Currency, Country, Description, Priority.
              <br/><br/>
              <strong style={{ color:'#94a3b8' }}>Workflow file:</strong> Columns: Alert Type ID (A), Alert Type Name (B), Source Step (C), Target Step (D). Workflow transitions will only be allowed from Source → Target.
              <br/><br/>
              <strong style={{ color:'#94a3b8' }}>Tip:</strong> Run <code style={{ fontFamily:"'IBM Plex Mono',monospace", color:'#93c5fd' }}>node generate-sample-data.js</code> to create sample Excel files.
            </div>
          </div>

          {error && <div style={{ background:'rgba(239,68,68,0.1)', border:'1px solid rgba(239,68,68,0.3)', borderRadius:8, padding:'10px 14px', color:'#fca5a5', fontSize:13, marginTop:16 }}>{error}</div>}

          <button onClick={launch} disabled={loading || !alertsFile}
            style={{ marginTop:24, width:'100%', background: !alertsFile ? 'rgba(30,41,59,0.5)' : 'linear-gradient(135deg,#1d4ed8,#3b82f6)', border:'none', borderRadius:8, padding:'13px', color: !alertsFile ? '#334155' : '#fff', fontSize:14, fontWeight:600, cursor: !alertsFile ? 'not-allowed' : 'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:8 }}>
            {loading ? 'Loading…' : <><ArrowRight size={16}/> Open Workbench</>}
          </button>
        </div>
      </div>
    </div>
  );
}

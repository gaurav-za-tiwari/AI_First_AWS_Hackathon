import React, { useState } from 'react';
import { Shield, LogOut, User, ChevronDown, Bell } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const roleBadge = { admin:'#f59e0b', supervisor:'#8b5cf6', analyst:'#3b82f6', readonly:'#6b7280' };

export default function Header({ alertCount }) {
  const { user, logout, permissions } = useAuth();
  const [showMenu, setShowMenu] = useState(false);

  return (
    <header style={{ background:'rgba(10,15,26,0.95)', borderBottom:'1px solid rgba(59,130,246,0.15)', padding:'0 24px', height:56, display:'flex', alignItems:'center', justifyContent:'space-between', backdropFilter:'blur(12px)', position:'sticky', top:0, zIndex:100, fontFamily:"'IBM Plex Sans', sans-serif" }}>
      
      {/* Left — brand */}
      <div style={{ display:'flex', alignItems:'center', gap:10 }}>
        <div style={{ width:32, height:32, borderRadius:8, background:'linear-gradient(135deg,#1d4ed8,#3b82f6)', display:'flex', alignItems:'center', justifyContent:'center' }}>
          <Shield size={17} color="#fff" />
        </div>
        <div>
          <span style={{ color:'#f1f5f9', fontSize:15, fontWeight:700, letterSpacing:'-0.3px' }}>AML Case Manager</span>
          <span style={{ color:'#334155', fontSize:11, marginLeft:10, fontFamily:"'IBM Plex Mono',monospace" }}>v1.0</span>
        </div>
      </div>

      {/* Right */}
      <div style={{ display:'flex', alignItems:'center', gap:16 }}>

        {/* Alert count badge */}
        {alertCount > 0 && (
          <div style={{ display:'flex', alignItems:'center', gap:6, background:'rgba(59,130,246,0.1)', border:'1px solid rgba(59,130,246,0.2)', borderRadius:20, padding:'4px 12px' }}>
            <Bell size={13} color="#3b82f6" />
            <span style={{ color:'#93c5fd', fontSize:12, fontFamily:"'IBM Plex Mono',monospace" }}>{alertCount} alerts loaded</span>
          </div>
        )}

        {/* User menu */}
        <div style={{ position:'relative' }}>
          <button onClick={() => setShowMenu(!showMenu)}
            style={{ display:'flex', alignItems:'center', gap:8, background:'rgba(30,41,59,0.6)', border:'1px solid rgba(71,85,105,0.4)', borderRadius:8, padding:'6px 12px', cursor:'pointer', color:'#e2e8f0' }}>
            <div style={{ width:26, height:26, borderRadius:'50%', background:`linear-gradient(135deg, ${roleBadge[user.role]}, ${roleBadge[user.role]}88)`, display:'flex', alignItems:'center', justifyContent:'center' }}>
              <User size={13} color="#fff" />
            </div>
            <div style={{ textAlign:'left' }}>
              <div style={{ fontSize:12, fontWeight:600, color:'#e2e8f0' }}>{user.name}</div>
              <div style={{ fontSize:10, color:'#64748b', textTransform:'uppercase', letterSpacing:.5 }}>{user.role}</div>
            </div>
            <ChevronDown size={13} color="#64748b" />
          </button>

          {showMenu && (
            <div style={{ position:'absolute', right:0, top:'calc(100% + 8px)', background:'#0f172a', border:'1px solid rgba(59,130,246,0.2)', borderRadius:10, minWidth:200, boxShadow:'0 16px 48px rgba(0,0,0,0.6)', overflow:'hidden', zIndex:200 }}>
              <div style={{ padding:'12px 16px', borderBottom:'1px solid rgba(71,85,105,0.3)' }}>
                <div style={{ color:'#94a3b8', fontSize:10, fontWeight:600, letterSpacing:1, marginBottom:6, textTransform:'uppercase' }}>Permissions</div>
                {Object.entries(permissions).map(([perm, has]) => (
                  <div key={perm} style={{ display:'flex', justifyContent:'space-between', marginBottom:3 }}>
                    <span style={{ color:'#64748b', fontSize:11 }}>{perm.replace('can','').replace(/([A-Z])/g,' $1').trim()}</span>
                    <span style={{ color: has ? '#4ade80' : '#475569', fontSize:11, fontFamily:"'IBM Plex Mono',monospace" }}>{has ? '✓' : '—'}</span>
                  </div>
                ))}
              </div>
              <button onClick={() => { setShowMenu(false); logout(); }}
                style={{ width:'100%', display:'flex', alignItems:'center', gap:10, padding:'12px 16px', background:'none', border:'none', cursor:'pointer', color:'#fca5a5', fontSize:13 }}
                onMouseEnter={e=>e.currentTarget.style.background='rgba(239,68,68,0.08)'}
                onMouseLeave={e=>e.currentTarget.style.background='none'}>
                <LogOut size={14} /> Sign Out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}

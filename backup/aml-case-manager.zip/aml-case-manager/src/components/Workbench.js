import React, { useState, useMemo } from 'react';
import { Search, Filter, ChevronDown, ChevronUp, RefreshCw, Download, SlidersHorizontal, X } from 'lucide-react';
import AlertDetail from './AlertDetail';
import { useAuth } from '../context/AuthContext';

const STATUS_COLOR = {
  'Open':      '#3b82f6',
  'In Review': '#f59e0b',
  'Escalated': '#ef4444',
  'Closed':    '#22c55e',
  'Rejected':  '#6b7280',
};
const PRIORITY_COLOR = { Critical:'#ef4444', High:'#f97316', Medium:'#eab308', Low:'#22c55e' };

function Badge({ label, color }) {
  return (
    <span style={{ background:`${color}22`, color, border:`1px solid ${color}44`, borderRadius:20, padding:'2px 9px', fontSize:11, fontWeight:600, whiteSpace:'nowrap' }}>
      {label}
    </span>
  );
}

export default function Workbench({ views, alertsByView, workflowMap, onReset }) {
  const { user, permissions } = useAuth();
  const [selectedView, setSelectedView] = useState(views[0] || '');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [priorityFilter, setPriorityFilter] = useState('All');
  const [sortKey, setSortKey] = useState('Score');
  const [sortDir, setSortDir] = useState('desc');
  const [selectedAlert, setSelectedAlert] = useState(null);
  const [alertsData, setAlertsData] = useState(alertsByView);
  const [showFilters, setShowFilters] = useState(false);
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 15;

  const rawAlerts = alertsData[selectedView] || [];

  // For analysts: only show alerts assigned to them
  const visibleAlerts = useMemo(() => {
    return permissions.canViewAll
      ? rawAlerts
      : rawAlerts.filter(a => a['Assigned To'] === user.id || a['Assigned To'] === user.username);
  }, [rawAlerts, permissions, user]);

  const filtered = useMemo(() => {
    let arr = [...visibleAlerts];
    if (search) {
      const q = search.toLowerCase();
      arr = arr.filter(a => Object.values(a).some(v => String(v).toLowerCase().includes(q)));
    }
    if (statusFilter !== 'All') arr = arr.filter(a => a['Status'] === statusFilter);
    if (priorityFilter !== 'All') arr = arr.filter(a => a['Priority'] === priorityFilter);
    arr.sort((a, b) => {
      const va = a[sortKey] ?? ''; const vb = b[sortKey] ?? '';
      const cmp = typeof va === 'number' ? va - vb : String(va).localeCompare(String(vb));
      return sortDir === 'asc' ? cmp : -cmp;
    });
    return arr;
  }, [visibleAlerts, search, statusFilter, priorityFilter, sortKey, sortDir]);

  const paginated = filtered.slice((page-1)*PAGE_SIZE, page*PAGE_SIZE);
  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);

  const handleSort = (key) => {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('desc'); }
  };

  const handleStatusChange = (alertId, newStatus) => {
    setAlertsData(prev => {
      const updated = { ...prev };
      updated[selectedView] = (updated[selectedView] || []).map(a =>
        a['Alert ID'] === alertId ? { ...a, Status: newStatus } : a
      );
      return updated;
    });
    if (selectedAlert && selectedAlert['Alert ID'] === alertId) {
      setSelectedAlert(prev => ({ ...prev, Status: newStatus }));
    }
  };

  const exportCSV = () => {
    const headers = filtered.length ? Object.keys(filtered[0]) : [];
    const rows = [headers.join(','), ...filtered.map(r => headers.map(h => `"${String(r[h] || '').replace(/"/g,'""')}"`).join(','))];
    const blob = new Blob([rows.join('\n')], { type:'text/csv' });
    const a = document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=`alerts_${selectedView}_${Date.now()}.csv`; a.click();
  };

  const SortIcon = ({ col }) => sortKey === col
    ? (sortDir === 'asc' ? <ChevronUp size={12}/> : <ChevronDown size={12}/>)
    : <span style={{width:12,display:'inline-block'}}/>;

  const statuses = ['All', ...new Set(rawAlerts.map(a => a['Status']).filter(Boolean))];
  const priorities = ['All', 'Critical','High','Medium','Low'];

  // Summary counts
  const counts = useMemo(() => {
    const c = {};
    visibleAlerts.forEach(a => { c[a['Status']] = (c[a['Status']] || 0) + 1; });
    return c;
  }, [visibleAlerts]);

  const TH = ({ col, children, style={} }) => (
    <th onClick={() => handleSort(col)} style={{ padding:'10px 12px', textAlign:'left', fontSize:11, fontWeight:700, color:'#475569', letterSpacing:.5, textTransform:'uppercase', cursor:'pointer', whiteSpace:'nowrap', userSelect:'none', ...style }}>
      <span style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
        {children} <SortIcon col={col}/>
      </span>
    </th>
  );

  return (
    <div style={{ background:'#0a0f1a', minHeight:'100vh', fontFamily:"'IBM Plex Sans',sans-serif", padding:'20px 24px' }}>

      {/* Top bar */}
      <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:20, flexWrap:'wrap' }}>

        {/* View selector */}
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <span style={{ color:'#475569', fontSize:12, fontWeight:600 }}>Alert View</span>
          <div style={{ position:'relative' }}>
            <select value={selectedView} onChange={e => { setSelectedView(e.target.value); setPage(1); }}
              style={{ appearance:'none', background:'rgba(15,23,42,0.8)', border:'1px solid rgba(59,130,246,0.3)', borderRadius:8, padding:'8px 32px 8px 12px', color:'#e2e8f0', fontSize:13, fontWeight:600, cursor:'pointer', outline:'none' }}>
              {views.map(v => <option key={v} value={v}>{v}</option>)}
            </select>
            <ChevronDown size={13} color="#475569" style={{ position:'absolute', right:10, top:'50%', transform:'translateY(-50%)', pointerEvents:'none' }} />
          </div>
        </div>

        {/* Search */}
        <div style={{ flex:1, position:'relative', maxWidth:340 }}>
          <Search size={14} color="#475569" style={{ position:'absolute', left:10, top:'50%', transform:'translateY(-50%)' }} />
          <input value={search} onChange={e => { setSearch(e.target.value); setPage(1); }}
            placeholder="Search alerts…"
            style={{ width:'100%', background:'rgba(15,23,42,0.8)', border:'1px solid rgba(71,85,105,0.4)', borderRadius:8, padding:'8px 12px 8px 32px', color:'#e2e8f0', fontSize:13, outline:'none', boxSizing:'border-box' }} />
          {search && <button onClick={() => setSearch('')} style={{ position:'absolute', right:8, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'#475569' }}><X size={13}/></button>}
        </div>

        {/* Filters toggle */}
        <button onClick={() => setShowFilters(!showFilters)}
          style={{ display:'flex', alignItems:'center', gap:6, background: showFilters ? 'rgba(59,130,246,0.15)' : 'rgba(30,41,59,0.6)', border:`1px solid ${showFilters ? 'rgba(59,130,246,0.4)' : 'rgba(71,85,105,0.4)'}`, borderRadius:8, padding:'8px 14px', cursor:'pointer', color: showFilters ? '#93c5fd' : '#94a3b8', fontSize:12, fontWeight:600 }}>
          <SlidersHorizontal size={13}/> Filters {(statusFilter!=='All'||priorityFilter!=='All') && <span style={{ background:'#3b82f6', color:'#fff', borderRadius:'50%', width:16, height:16, fontSize:10, display:'inline-flex', alignItems:'center', justifyContent:'center' }}>!</span>}
        </button>

        <div style={{ marginLeft:'auto', display:'flex', gap:8 }}>
          <button onClick={exportCSV} style={{ display:'flex', alignItems:'center', gap:6, background:'rgba(30,41,59,0.6)', border:'1px solid rgba(71,85,105,0.4)', borderRadius:8, padding:'8px 14px', cursor:'pointer', color:'#94a3b8', fontSize:12, fontWeight:600 }}>
            <Download size={13}/> Export CSV
          </button>
          <button onClick={onReset} style={{ display:'flex', alignItems:'center', gap:6, background:'rgba(30,41,59,0.6)', border:'1px solid rgba(71,85,105,0.4)', borderRadius:8, padding:'8px 14px', cursor:'pointer', color:'#94a3b8', fontSize:12, fontWeight:600 }}>
            <RefreshCw size={13}/> Load New Files
          </button>
        </div>
      </div>

      {/* Filter panel */}
      {showFilters && (
        <div style={{ background:'rgba(15,23,42,0.8)', border:'1px solid rgba(71,85,105,0.3)', borderRadius:10, padding:'14px 18px', marginBottom:16, display:'flex', gap:20, alignItems:'center', flexWrap:'wrap' }}>
          <div>
            <span style={{ color:'#475569', fontSize:11, fontWeight:600, marginRight:8, textTransform:'uppercase' }}>Status</span>
            {statuses.map(s => (
              <button key={s} onClick={() => { setStatusFilter(s); setPage(1); }}
                style={{ margin:'0 3px', padding:'4px 12px', borderRadius:20, border:`1px solid ${statusFilter===s ? (STATUS_COLOR[s]||'#3b82f6') : 'rgba(71,85,105,0.4)'}`, background: statusFilter===s ? `${STATUS_COLOR[s]||'#3b82f6'}22` : 'transparent', color: statusFilter===s ? (STATUS_COLOR[s]||'#93c5fd') : '#64748b', fontSize:11, fontWeight:600, cursor:'pointer' }}>
                {s}
              </button>
            ))}
          </div>
          <div>
            <span style={{ color:'#475569', fontSize:11, fontWeight:600, marginRight:8, textTransform:'uppercase' }}>Priority</span>
            {priorities.map(p => (
              <button key={p} onClick={() => { setPriorityFilter(p); setPage(1); }}
                style={{ margin:'0 3px', padding:'4px 12px', borderRadius:20, border:`1px solid ${priorityFilter===p ? (PRIORITY_COLOR[p]||'#3b82f6') : 'rgba(71,85,105,0.4)'}`, background: priorityFilter===p ? `${PRIORITY_COLOR[p]||'#3b82f6'}22` : 'transparent', color: priorityFilter===p ? (PRIORITY_COLOR[p]||'#93c5fd') : '#64748b', fontSize:11, fontWeight:600, cursor:'pointer' }}>
                {p}
              </button>
            ))}
          </div>
          <button onClick={() => { setStatusFilter('All'); setPriorityFilter('All'); }} style={{ background:'none', border:'none', color:'#ef4444', fontSize:11, cursor:'pointer', marginLeft:'auto' }}>Clear filters</button>
        </div>
      )}

      {/* Summary pills */}
      <div style={{ display:'flex', gap:8, marginBottom:16, flexWrap:'wrap' }}>
        {Object.entries(counts).map(([status, n]) => (
          <div key={status} style={{ display:'flex', alignItems:'center', gap:6, background:'rgba(15,23,42,0.6)', border:'1px solid rgba(71,85,105,0.25)', borderRadius:8, padding:'6px 12px' }}>
            <span style={{ width:8, height:8, borderRadius:'50%', background: STATUS_COLOR[status]||'#475569', display:'inline-block' }} />
            <span style={{ color:'#94a3b8', fontSize:11 }}>{status}</span>
            <span style={{ color:'#f1f5f9', fontSize:12, fontWeight:700, fontFamily:"'IBM Plex Mono',monospace" }}>{n}</span>
          </div>
        ))}
        <div style={{ marginLeft:'auto', color:'#475569', fontSize:12, alignSelf:'center' }}>
          {filtered.length} of {visibleAlerts.length} alerts
          {!permissions.canViewAll && <span style={{ color:'#334155', fontSize:11 }}> (assigned to you)</span>}
        </div>
      </div>

      {/* Table */}
      <div style={{ background:'rgba(10,15,26,0.6)', border:'1px solid rgba(71,85,105,0.2)', borderRadius:12, overflow:'hidden' }}>
        <div style={{ overflowX:'auto' }}>
          <table style={{ width:'100%', borderCollapse:'collapse', minWidth:800 }}>
            <thead style={{ background:'rgba(15,23,42,0.8)', borderBottom:'1px solid rgba(71,85,105,0.3)' }}>
              <tr>
                <TH col="Alert ID">Alert ID</TH>
                <TH col="Customer Name">Customer</TH>
                <TH col="Alert Type">Type</TH>
                <TH col="Score" style={{ textAlign:'right' }}>Score</TH>
                <TH col="Status">Status</TH>
                <TH col="Priority">Priority</TH>
                <TH col="Amount" style={{ textAlign:'right' }}>Amount</TH>
                <TH col="Country">Country</TH>
                <TH col="Assigned To">Assigned</TH>
                <TH col="Created Date">Created</TH>
              </tr>
            </thead>
            <tbody>
              {paginated.length === 0 ? (
                <tr><td colSpan={10} style={{ textAlign:'center', padding:'48px 0', color:'#334155', fontSize:13 }}>No alerts match your filters</td></tr>
              ) : paginated.map((alert, i) => (
                <tr key={alert['Alert ID'] || i}
                  onClick={() => setSelectedAlert(alert)}
                  style={{ borderBottom:'1px solid rgba(71,85,105,0.15)', cursor:'pointer', transition:'background .1s' }}
                  onMouseEnter={e => e.currentTarget.style.background='rgba(59,130,246,0.05)'}
                  onMouseLeave={e => e.currentTarget.style.background='transparent'}>
                  <td style={{ padding:'12px 12px', fontSize:12, fontFamily:"'IBM Plex Mono',monospace", color:'#93c5fd', whiteSpace:'nowrap' }}>{alert['Alert ID']}</td>
                  <td style={{ padding:'12px 12px' }}>
                    <div style={{ color:'#e2e8f0', fontSize:13, fontWeight:500 }}>{alert['Customer Name']}</div>
                    <div style={{ color:'#475569', fontSize:11, fontFamily:"'IBM Plex Mono',monospace" }}>{alert['Customer ID']}</div>
                  </td>
                  <td style={{ padding:'12px 12px', color:'#94a3b8', fontSize:12, maxWidth:180 }}>
                    <div style={{ overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{alert['Alert Type']}</div>
                  </td>
                  <td style={{ padding:'12px 12px', textAlign:'right' }}>
                    <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:13, fontWeight:700, color: alert['Score'] >= 90 ? '#ef4444' : alert['Score'] >= 75 ? '#f97316' : '#eab308' }}>
                      {alert['Score']}
                    </span>
                  </td>
                  <td style={{ padding:'12px 12px' }}><Badge label={alert['Status']} color={STATUS_COLOR[alert['Status']]||'#475569'}/></td>
                  <td style={{ padding:'12px 12px' }}><Badge label={alert['Priority']} color={PRIORITY_COLOR[alert['Priority']]||'#475569'}/></td>
                  <td style={{ padding:'12px 12px', textAlign:'right', color:'#94a3b8', fontSize:12, fontFamily:"'IBM Plex Mono',monospace", whiteSpace:'nowrap' }}>
                    {alert['Amount'] ? `${Number(alert['Amount']).toLocaleString()} ${alert['Currency']}` : '—'}
                  </td>
                  <td style={{ padding:'12px 12px', color:'#64748b', fontSize:12, fontFamily:"'IBM Plex Mono',monospace" }}>{alert['Country']}</td>
                  <td style={{ padding:'12px 12px', color:'#64748b', fontSize:12, fontFamily:"'IBM Plex Mono',monospace" }}>{alert['Assigned To']}</td>
                  <td style={{ padding:'12px 12px', color:'#475569', fontSize:11, fontFamily:"'IBM Plex Mono',monospace", whiteSpace:'nowrap' }}>
                    {alert['Created Date'] ? String(alert['Created Date']).split('T')[0] : ''}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div style={{ display:'flex', alignItems:'center', justifyContent:'center', gap:8, padding:'12px', borderTop:'1px solid rgba(71,85,105,0.2)' }}>
            <button onClick={() => setPage(p => Math.max(1,p-1))} disabled={page===1}
              style={{ background:'rgba(30,41,59,0.6)', border:'1px solid rgba(71,85,105,0.3)', borderRadius:6, padding:'5px 12px', color: page===1 ? '#334155' : '#94a3b8', cursor: page===1 ? 'default' : 'pointer', fontSize:12 }}>‹ Prev</button>
            {Array.from({length:totalPages},(_,i)=>i+1).map(p => (
              <button key={p} onClick={() => setPage(p)}
                style={{ background: p===page ? 'rgba(59,130,246,0.2)' : 'rgba(30,41,59,0.4)', border:`1px solid ${p===page ? 'rgba(59,130,246,0.5)' : 'rgba(71,85,105,0.2)'}`, borderRadius:6, padding:'5px 10px', color: p===page ? '#93c5fd' : '#64748b', cursor:'pointer', fontSize:12, fontFamily:"'IBM Plex Mono',monospace", minWidth:32 }}>
                {p}
              </button>
            ))}
            <button onClick={() => setPage(p => Math.min(totalPages,p+1))} disabled={page===totalPages}
              style={{ background:'rgba(30,41,59,0.6)', border:'1px solid rgba(71,85,105,0.3)', borderRadius:6, padding:'5px 12px', color: page===totalPages ? '#334155' : '#94a3b8', cursor: page===totalPages ? 'default' : 'pointer', fontSize:12 }}>Next ›</button>
          </div>
        )}
      </div>

      {/* Alert detail modal */}
      {selectedAlert && (
        <AlertDetail
          alert={selectedAlert}
          workflowMap={workflowMap}
          onClose={() => setSelectedAlert(null)}
          onStatusChange={handleStatusChange}
        />
      )}
    </div>
  );
}

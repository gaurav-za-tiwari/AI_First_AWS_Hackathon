import React, { createContext, useContext, useState } from 'react';

const AuthContext = createContext(null);

// Hardcoded users for demo — in production these would come from a backend
export const USERS = [
  { id: 'admin1',     username: 'admin',     password: 'admin123',     name: 'Admin User',        role: 'admin',      email: 'admin@amlbank.com' },
  { id: 'supervisor1',username: 'supervisor',password: 'super123',     name: 'Jane Supervisor',   role: 'supervisor', email: 'j.supervisor@amlbank.com' },
  { id: 'analyst1',  username: 'analyst1',   password: 'analyst123',   name: 'Alex Analyst',      role: 'analyst',    email: 'a.analyst@amlbank.com' },
  { id: 'analyst2',  username: 'analyst2',   password: 'analyst123',   name: 'Brett Analyst',     role: 'analyst',    email: 'b.analyst@amlbank.com' },
  { id: 'analyst3',  username: 'analyst3',   password: 'analyst123',   name: 'Carol Analyst',     role: 'analyst',    email: 'c.analyst@amlbank.com' },
  { id: 'readonly1', username: 'readonly',   password: 'readonly123',  name: 'Read Only User',    role: 'readonly',   email: 'readonly@amlbank.com' },
];

export const ROLE_PERMISSIONS = {
  admin:      { canView: true,  canEdit: true,  canTransition: true,  canAssign: true,  canUpload: true,  canViewAll: true  },
  supervisor: { canView: true,  canEdit: true,  canTransition: true,  canAssign: true,  canUpload: false, canViewAll: true  },
  analyst:    { canView: true,  canEdit: true,  canTransition: true,  canAssign: false, canUpload: false, canViewAll: false },
  readonly:   { canView: true,  canEdit: false, canTransition: false, canAssign: false, canUpload: false, canViewAll: true  },
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [error, setError] = useState('');

  const login = (username, password) => {
    const found = USERS.find(u => u.username === username && u.password === password);
    if (found) {
      setUser(found);
      setError('');
      return true;
    }
    setError('Invalid username or password');
    return false;
  };

  const logout = () => setUser(null);

  const permissions = user ? ROLE_PERMISSIONS[user.role] : {};

  return (
    <AuthContext.Provider value={{ user, login, logout, error, setError, permissions }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}

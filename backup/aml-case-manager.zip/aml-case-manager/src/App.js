import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import Login from './components/Login';
import Header from './components/Header';
import SetupScreen from './components/SetupScreen';
import Workbench from './components/Workbench';

function AppContent() {
  const { user } = useAuth();
  const [workbenchData, setWorkbenchData] = useState(null);

  if (!user) return <Login />;

  const totalAlerts = workbenchData
    ? Object.values(workbenchData.alertsByView).reduce((n,a) => n+a.length, 0)
    : 0;

  return (
    <div style={{ background:'#0a0f1a', minHeight:'100vh' }}>
      <Header alertCount={totalAlerts} />
      {!workbenchData
        ? <SetupScreen onReady={setWorkbenchData} />
        : <Workbench {...workbenchData} onReset={() => setWorkbenchData(null)} />
      }
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

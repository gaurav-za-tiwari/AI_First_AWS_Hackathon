import * as XLSX from 'xlsx';

/**
 * Parse the alerts Excel workbook.
 * Returns: { views: string[], alertsByView: { [viewName]: Alert[] } }
 */
export async function parseAlertsWorkbook(file) {
  const buffer = await file.arrayBuffer();
  const wb = XLSX.read(buffer, { type: 'array', cellDates: true });

  const views = wb.SheetNames;
  const alertsByView = {};

  views.forEach(sheetName => {
    const ws = wb.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json(ws, { defval: '' });
    // Normalize column names (trim whitespace)
    const normalized = rows.map(row => {
      const obj = {};
      Object.keys(row).forEach(k => { obj[k.trim()] = row[k]; });
      return obj;
    });
    alertsByView[sheetName] = normalized;
  });

  return { views, alertsByView };
}

/**
 * Parse the workflow config Excel workbook.
 * Returns: { [alertTypeId]: { name: string, transitions: { from: string, to: string[] }[] } }
 */
export async function parseWorkflowWorkbook(file) {
  const buffer = await file.arrayBuffer();
  const wb = XLSX.read(buffer, { type: 'array' });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json(ws, { defval: '' });

  const workflow = {};

  rows.forEach(row => {
    const id = String(row['Alert Type ID'] || '').trim();
    const name = String(row['Alert Type Name'] || '').trim();
    const src  = String(row['Source Step']   || '').trim();
    const tgt  = String(row['Target Step']   || '').trim();

    if (!id || !src || !tgt) return;

    if (!workflow[id]) {
      workflow[id] = { name, transitions: {} };
    }
    if (!workflow[id].transitions[src]) {
      workflow[id].transitions[src] = [];
    }
    if (!workflow[id].transitions[src].includes(tgt)) {
      workflow[id].transitions[src].push(tgt);
    }
  });

  return workflow;
}

/**
 * Given a workflow map and an alert, return the allowed next statuses.
 */
export function getAllowedTransitions(workflowMap, alertTypeId, currentStatus) {
  const id = String(alertTypeId);
  const cfg = workflowMap[id];
  if (!cfg) return [];
  return cfg.transitions[currentStatus] || [];
}

// run-once script to generate sample Excel files using Node.js
// npm install xlsx then: node generate-sample-data.js

const XLSX = require('xlsx');

// ─── ALERTS WORKBOOK ─────────────────────────────────────────────────────────
// Sheet names = Alert Views
const alertViews = {
  'Party IB': [
    ['Alert ID','Customer ID','Customer Name','Alert Type','Alert Type ID','Score','Status','Assigned To','Created Date','Amount','Currency','Country','Description','Priority'],
    ['ALT-00001','C10021','John Matthews','AML IB Americas',1,87,'Open','analyst1','2024-01-15',250000,'USD','US','Structuring - multiple cash deposits below threshold','High'],
    ['ALT-00002','C10034','Sarah Chen','AML IB APAC',2,91,'In Review','analyst2','2024-01-16',520000,'HKD','HK','Wire transfers to high-risk jurisdiction','Critical'],
    ['ALT-00003','C10055','Carlos Rivera','AML IB EMEA',3,73,'Open','analyst1','2024-01-17',80000,'EUR','ES','Rapid movement of funds through multiple accounts','Medium'],
    ['ALT-00004','C10072','Priya Sharma','AML IB APAC',2,95,'Escalated','supervisor1','2024-01-18',1200000,'SGD','SG','Large cross-border transactions inconsistent with profile','Critical'],
    ['ALT-00005','C10088','Michael Brown','AML IB Americas',1,65,'Open','analyst2','2024-01-19',45000,'USD','MX','Unusual cash activity for business type','Low'],
    ['ALT-00006','C10093','Fatima Al-Said','AML IB EMEA',3,82,'Closed','analyst1','2024-01-20',310000,'GBP','AE','Transactions linked to PEP network','High'],
    ['ALT-00007','C10101','Zhang Wei','AML IB APAC',2,78,'Open','analyst3','2024-01-21',680000,'CNY','CN','Frequent round-number transactions','Medium'],
    ['ALT-00008','C10115','Elena Petrov','AML IB EMEA',3,88,'In Review','analyst2','2024-01-22',420000,'EUR','RU','Shell company involvement suspected','High'],
  ],
  'Party WMA': [
    ['Alert ID','Customer ID','Customer Name','Alert Type','Alert Type ID','Score','Status','Assigned To','Created Date','Amount','Currency','Country','Description','Priority'],
    ['ALT-00101','W20011','Robert Kline','AML WMA Americas',4,76,'Open','analyst1','2024-01-15',900000,'USD','US','Unusual portfolio liquidation pattern','High'],
    ['ALT-00102','W20025','Mei Ling','AML WMA APAC',5,84,'In Review','analyst3','2024-01-16',2100000,'HKD','HK','Transfer of wealth inconsistent with known sources','Critical'],
    ['ALT-00103','W20037','Oliver Smith','AML WMA EMEA',6,67,'Open','analyst2','2024-01-17',550000,'GBP','UK','Rapid in-and-out trading with no business rationale','Medium'],
    ['ALT-00104','W20049','Ingrid Hansen','AML WMA EMEA',6,92,'Escalated','supervisor1','2024-01-18',3400000,'SEK','SE','Multiple beneficial owners - UBO verification failed','Critical'],
    ['ALT-00105','W20058','David Nkosi','AML WMA Africa',7,71,'Open','analyst1','2024-01-19',120000,'ZAR','ZA','Cross-border wire to unverified beneficiary','Medium'],
  ],
  'Party CB': [
    ['Alert ID','Customer ID','Customer Name','Alert Type','Alert Type ID','Score','Status','Assigned To','Created Date','Amount','Currency','Country','Description','Priority'],
    ['ALT-00201','B30001','Apex Holdings Ltd','AML CB Corporate',8,89,'Open','analyst2','2024-01-15',5200000,'USD','KY','Large correspondent banking flow - high-risk domicile','Critical'],
    ['ALT-00202','B30012','Solaris Trade Co','AML CB Trade Finance',9,74,'In Review','analyst1','2024-01-16',780000,'EUR','DE','Trade-based money laundering indicators','High'],
    ['ALT-00203','B30023','Pacific Bridge Inc','AML CB Corporate',8,61,'Open','analyst3','2024-01-17',330000,'USD','PA','Frequent small transfers avoiding reporting threshold','Medium'],
    ['ALT-00204','B30031','Global Nexus LLC','AML CB Trade Finance',9,95,'Escalated','supervisor1','2024-01-18',8900000,'USD','HK','Phantom shipment documentation detected','Critical'],
  ]
};

const alertsWb = XLSX.utils.book_new();
Object.entries(alertViews).forEach(([sheetName, rows]) => {
  const ws = XLSX.utils.aoa_to_sheet(rows);
  ws['!cols'] = [{wch:12},{wch:10},{wch:20},{wch:18},{wch:14},{wch:8},{wch:12},{wch:14},{wch:14},{wch:14},{wch:10},{wch:8},{wch:50},{wch:10}];
  XLSX.utils.book_append_sheet(alertsWb, ws, sheetName);
});
XLSX.writeFile(alertsWb, 'public/alerts_data.xlsx');
console.log('✅ alerts_data.xlsx created in public/');

// ─── WORKFLOW WORKBOOK ────────────────────────────────────────────────────────
const workflowRows = [
  ['Alert Type ID','Alert Type Name','Source Step','Target Step'],
  // Alert Type 1: AML IB Americas
  [1,'AML IB Americas','Open','In Review'],
  [1,'AML IB Americas','In Review','Escalated'],
  [1,'AML IB Americas','In Review','Closed'],
  [1,'AML IB Americas','Escalated','Closed'],
  [1,'AML IB Americas','Escalated','Rejected'],
  // Alert Type 2: AML IB APAC
  [2,'AML IB APAC','Open','In Review'],
  [2,'AML IB APAC','Open','Escalated'],
  [2,'AML IB APAC','In Review','Escalated'],
  [2,'AML IB APAC','In Review','Closed'],
  [2,'AML IB APAC','Escalated','Closed'],
  [2,'AML IB APAC','Escalated','Rejected'],
  // Alert Type 3: AML IB EMEA
  [3,'AML IB EMEA','Open','In Review'],
  [3,'AML IB EMEA','In Review','Escalated'],
  [3,'AML IB EMEA','In Review','Closed'],
  [3,'AML IB EMEA','Escalated','Closed'],
  // Alert Type 4: AML WMA Americas
  [4,'AML WMA Americas','Open','In Review'],
  [4,'AML WMA Americas','In Review','Closed'],
  [4,'AML WMA Americas','In Review','Rejected'],
  // Alert Type 5: AML WMA APAC
  [5,'AML WMA APAC','Open','In Review'],
  [5,'AML WMA APAC','In Review','Escalated'],
  [5,'AML WMA APAC','Escalated','Closed'],
  // Alert Type 6: AML WMA EMEA
  [6,'AML WMA EMEA','Open','In Review'],
  [6,'AML WMA EMEA','In Review','Escalated'],
  [6,'AML WMA EMEA','In Review','Closed'],
  [6,'AML WMA EMEA','Escalated','Closed'],
  [6,'AML WMA EMEA','Escalated','Rejected'],
  // Alert Type 7: AML WMA Africa
  [7,'AML WMA Africa','Open','In Review'],
  [7,'AML WMA Africa','In Review','Closed'],
  // Alert Type 8: AML CB Corporate
  [8,'AML CB Corporate','Open','In Review'],
  [8,'AML CB Corporate','In Review','Escalated'],
  [8,'AML CB Corporate','In Review','Closed'],
  [8,'AML CB Corporate','Escalated','Closed'],
  [8,'AML CB Corporate','Escalated','Rejected'],
  // Alert Type 9: AML CB Trade Finance
  [9,'AML CB Trade Finance','Open','In Review'],
  [9,'AML CB Trade Finance','In Review','Escalated'],
  [9,'AML CB Trade Finance','Escalated','Closed'],
  [9,'AML CB Trade Finance','Escalated','Rejected'],
];

const wfWb = XLSX.utils.book_new();
const wfWs = XLSX.utils.aoa_to_sheet(workflowRows);
wfWs['!cols'] = [{wch:14},{wch:20},{wch:16},{wch:16}];
XLSX.utils.book_append_sheet(wfWb, wfWs, 'Workflow Config');
XLSX.writeFile(wfWb, 'public/workflow_config.xlsx');
console.log('✅ workflow_config.xlsx created in public/');
